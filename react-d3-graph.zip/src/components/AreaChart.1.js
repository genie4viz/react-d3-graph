import React, {
    Component
} from 'react';
import * as d3 from "d3";
import svg from 'react-svg'
import './areachart.scss';

// class Handle extends React.Component {
//     constructor(props){
//         super(props);
//         this.state = {
//             svgDimen: null,
//             data: [],
//             margins: null,            
//             handle: ''
//         }
//     }
//     onMouseOver(){
//         this.setState({
//             handle: this.props.handle
//         });
//     }
//     render() {
//         const {initialValue,xScale,handle} = this.props;
//         const circle = <circle r="10px" fill="#fa7070"/>

//         return <g className={handle} transform={`translate(${xScale(initialValue)},0)`}
//             onMouseOver={this.onMouseOver.bind(this)}>{circle}</g>
//     }

//     componentDidUpdate(prevProps, prevState){
//         let {margins, svgDimensions} = prevProps;
//         let mouseValue, trueMouseValue, self = this;
//         let handle = this.state.handle;
//         let h1, h2;
//         let tempH1, tempH2, trueYear1, trueYear2;
//         let minWidth = ((window.screen.width/2 - margins.left - margins.right)/5);

//         const drag = d3.drag()
//             .on("drag",draged).on("end",dragend);

//         d3.select(".rangeSliderGroup").call(drag);

//         function draged(){
//             mouseValue = d3.mouse(this)[0];
//             trueMouseValue = getTrueMouseValue(mouseValue);

//             handle === "handleLeft" ? h1 = mouseValue : h2 = mouseValue;

//             if ((h2 - h1) > minWidth && mouseValue > margins.left && mouseValue < (svgDimensions.width - margins.right)){
//             d3.select("." + self.state.handle).attr("transform","translate("+ mouseValue + ",0)");
//                 if (handle === "handleLeft") {
//                     tempH1 = mouseValue;
//                     trueYear1 = trueMouseValue;
//                 } else {
//                     tempH2 = mouseValue
//                     trueYear2 = trueMouseValue;
//                 }
//             } else {
//                 h1 = tempH1;
//                 h2 = tempH2;
//                 handle === "handleLeft" ? trueMouseValue = trueYear1 : trueMouseValue = trueYear2;
//             }
//             d3.select(".rangeBarFilled").remove();
//             d3.select(".rangeSliderGroup")
//                 .insert("line",".rangeSliderGraphAxis")
//                 .attr("x1",h1)
//                 .attr("x2",h2)
//                 .attr("y1",0)
//                 .attr("y2",0)
//                 .attr("class","rangeBarFilled")

//         }
//         function dragend() {
//             h1 = xScale(getTrueMouseValue(tempH1));
//             h2 = xScale(getTrueMouseValue(tempH2));

//             d3.select("."+self.state.handle).attr("transform","translate("+xScale(trueMouseValue)+",0)");
//             d3.select(".rangeBarFilled").remove();
//             d3.select(".rangeSliderGroup")
//                 .insert("line",".rangeSliderGraphAxis")
//                 .attr("x1",xScale(trueYear1))
//                 .attr("x2",xScale(trueYear2))
//                 .attr("y1",0)
//                 .attr("y2",0)
//                 .attr("class","rangeBarFilled");

//             // onChangeYear(trueYear1,trueYear2);
//         }
//         function getTrueMouseValue(mouseValue){
//             return Math.round(xScale.invert(mouseValue));
//         }
//     }
// }
// class GraphAxis extends React.Component {
//     constructor(props){
//         super(props);
//         this.state = {
//             margins: null,
//             svgDimen: null,
//             years: []
//         }
//     }
//     componentDidMount(){
//         this.renderGraphAxis();
//     }
//     componentDidUpdate(){
//         this.renderGraphAxis();
//     }
//     static getDerivedStateFromProps(nextProps, prevState) {        
//         const {margins, svgDimen, years} = nextProps;        
//         let newProps = {
//             years: years,            
//             margins: margins,
//             svgDimen: svgDimen
//         }
//         if(prevState !== newProps)
//             return newProps; //set newProps to state
//         return null;// no changes
//     }
//     renderGraphAxis(){        
//         const {svgDimen, margins, years} = this.state;
//         let first = years[0];
//         let last = years[years.length - 1];
//         let xScale = d3.scaleLinear()
//             .domain([first, last])
//             .range([margins.left, svgDimen.width - margins.right])
//             .clamp(true);
        
//         d3.select(this.GraphAxisElement)
//         .call(d3.GraphAxisBottom()
//             .scale(xScale)
//             .ticks(years.length)
//             .tickFormat(d3.format(""))
//         )
//         .selectAll("text")
//         .style('opacity', d => d === first || d === last ? 1 : 0)
//         .style("font-size","14px")
//         .style("fill","black");

//         d3.select(this.GraphAxisElement).selectAll("line").attr("stroke","white");//set black when shows GraphAxis
//         d3.select(this.GraphAxisElement).select("path").style("d","none")
//     }
//     render() {        
//         return <g className="sliderGraphAxis" transform="translate(0,30)" ref={el => this.GraphAxisElement = el } />;
//     }
// }
// class RangeSlider extends Component {
//     constructor(props){
//         super(props);
//         this.state = {
//             width: 0,
//             height: 0,
//             data: []
//         }
//     }
//     static getDerivedStateFromProps(nextProps, prevState) {        
//         const {data, width, height, onChangeYear} = nextProps;        
//         let newProps = {
//             data: data,            
//             width: width,
//             height: height,
//             onChangeYear: onChangeYear,
//         }
//         if(prevState !== newProps)
//             return newProps; //set newProps to state
//         return null;// no changes
//     }    
//     render(){
//         const {width, height, data, onChangeYear} = this.state;        
//         const margins = {top: 20, right: 50, bottom: 20, left: 50},
//             svgDimen = {width: width - margins.left - margins.right, height: height/6 };        
//             const RangeBar = <line x1={margins.left} y1="20" x2={svgDimen.width - margins.right} y2="20" className="rangeBar" />;

//         return  <svg className="rangeSliderSvg" width={svgDimen.width} height={svgDimen.height}>
//                     <g className="rangeSliderGroup" transform={`translate(0,${svgDimen.height - margins.bottom - 40})`}>
//                         {RangeBar}
//                         <GraphAxis margins={margins} svgDimen={svgDimen} data={data} />
//                         <Handle onChangeYear={onChangeYear} handle="handleLeft" years={data} margins={margins} svgDimen={svgDimen} />
//                         <Handle onChangeYear={onChangeYear} handle="handleRight" years={data} margins={margins} svgDimen={svgDimen} />
//                     </g>
//                 </svg>;
//     }
    
// }

class AreaChart extends Component {
    constructor(props){
        super(props);
        this.state = {
            data: [],
            width: 0,
            height: 0
        };
    }    
    static getDerivedStateFromProps(nextProps, prevState) {     
        const {data, width, height} = nextProps;
        console.log(data)
        // let spt = data[0].toString().split(';');
        
        let newProps = {
            data: data,
            width: width,
            height: height
        }
        if(prevState !== newProps)
            return newProps; //set newProps to state
        return null;// no changes
    }    
    componentDidMount(){
    }
    handlePeriodYear = (startYear, endYear) => {
        const {data} = this.state;
        for(let i = 0; i < data.length; i++){
            if(data[i].year === startYear){                
                this.setState({
                    balanceChartData: data[i].values
                });
                break;
            }
        }        
    }
    render() {
        return  <div className="areaChart">                    
                </div>;
    }
}

export default AreaChart;