import React, {
    Component
} from 'react';
import * as d3 from "d3";
import svg from 'react-svg'
import './areachart.scss';

class Chart extends Component {
    constructor(props){
        super(props);
        this.state = {
            margins: null,
            svgDimen: null,
            partial: []
        }
    }
    static getDerivedStateFromProps(nextProps, prevState) {        
        const {partial, margins, svgDimen} = nextProps;        
        let newProps = {
            partial: partial,
            margins: margins,
            svgDimen: svgDimen
        }
        if(prevState !== newProps)
            return newProps; //set newProps to state
        return null;// no changes
    }    
    componentDidMount(){
        this.drawGraph();
    }
    componentDidUpdate(){
        this.drawGraph();
    }
    drawGraph(){
        const {svgDimen, margins, partial} = this.state;        
        
        let data = partial.columns.slice(1, 3).map(function(id){
            return {
                id: id,
                values: partial.map(function(d){
                    return{
                        year: d.year,
                        value: d[id]
                    }
                })
            };
        });
        console.log(data);
        let start = data[0].values[0].year, end = data[0].values[data[0].values.length - 1].year;
        var color = d3.scaleOrdinal()
            .domain(["grey", "red"])
            .range(["rgba(189, 187, 188, 0.7)", "rgba(223, 7, 44, 0.7)"]);
        let x = d3.scaleLinear()
            .range([margins.left, svgDimen.width - margins.right])
            .domain([start, end]);
        let y = d3.scaleLinear()
            .range([svgDimen.height - margins.bottom , margins.top])
            .domain([0, 100]);
        
        color.domain(data.map(function(c) { return c.id; }));
        
        let area = d3.area()
            .curve(d3.curveMonotoneX)
            .x(d=> x(d.year))
            .y0(y(0))
            .y1(d => y(d.value));

        let graph = d3.select(this.el);
        graph.selectAll("*").remove();

        graph.append("g")
            .attr("transform", "translate(0," + (svgDimen.height - margins.bottom) + ")")
            .call(d3.axisBottom()
                .scale(x)
                .ticks(data[0].values.length)
                .tickSize(0)
                .tickFormat(d3.format(""))
            )                        
            .selectAll("text")        
            .style("font-size","10px")
            .style("fill","black");
        graph
            .append("g")
            .call(d3.axisLeft()
                .scale(y)
                .ticks(10)
                .tickSize(0)                
            )
            .select(".domain").style('opacity', 0);
        
        graph.selectAll(".area")
            .data(data)
            .enter().append("path")
                .attr("d", (d) => area(d.values))
                .style("fill", (d) => color(d.id));
        // graph.selectAll("line").attr("stroke","white");//set black when shows GraphAxis
        // graph.select("path").style("d","none");
    }
    render(){
        const {svgDimen} = this.state;
        return  <svg className="graphSvg" width={svgDimen.width} height={svgDimen.height}>
                    <g className="graphPane" ref={el => this.el = el}></g>
                </svg>;
    }
    
}

class Handle extends React.Component {    
    constructor(props){
        super(props);
        this.state = {            
            handle: ''
        }
    }
    static getDerivedStateFromProps(nextProps, prevState) {
        
        const {svgDimen, rangeValues, initValue, margins, years, xScale, onChangePeriod} = nextProps;
        let newProps = {
            svgDimen: svgDimen,            
            margins: margins,
            years: years,
            initValue: initValue,
            rangeValues: rangeValues,
            onChangePeriod: onChangePeriod,
            xScale: xScale
        }
        if(prevState !== newProps)
            return newProps; //set newProps to state
        return null;// no changes
    }
    onMouseOver(){
        this.setState({
            handle: this.props.handle
        });
    }
    render() {
        // console.log("render")
        const {svgDimen, margins, initValue, xScale, handle} = this.props;        
        const rect = <rect rx="3" ry="3" width="10" height={svgDimen.height - margins.bottom} transform={`translate(-5,0)`} fill="#df072c"/>;
        return <g className={handle} transform={`translate(${xScale(initValue)},0)`}
            onMouseOver={this.onMouseOver.bind(this)}>{rect}</g>
    }

    componentDidUpdate(prevProps, prevState){
        let {margins, svgDimen, xScale, years, handle, rangeValues, onChangePeriod} = this.state;
        
        var mouseValue, trueMouseValue, self = this;        
        let minWidth = (svgDimen.width - margins.left - margins.right) / years.length;        

        const drag = d3.drag().on("start", dragstart).on("drag",draged).on("end",dragend);

        d3.select(".graphSliderGroup").call(drag);
        function dragstart(){
            mouseValue = d3.mouse(this)[0];
            trueMouseValue = getTrueMouseValue(mouseValue);
        }
        function draged(){
            mouseValue = d3.mouse(this)[0];
            trueMouseValue = getTrueMouseValue(mouseValue);
            
            handle === "handleLeft" ? rangeValues.h1 = mouseValue : rangeValues.h2 = mouseValue;
            
            if ((rangeValues.h2 - rangeValues.h1) > minWidth && mouseValue > margins.left && mouseValue < (svgDimen.width - margins.right)){                
                d3.select("." + self.state.handle).attr("transform","translate("+ mouseValue + ",0)");
                if (handle === "handleLeft") {
                    rangeValues.tempH1 = mouseValue;
                    rangeValues.trueYear1 = trueMouseValue;
                } else {
                    rangeValues.tempH2 = mouseValue
                    rangeValues.trueYear2 = trueMouseValue;
                }
            } else {                
                rangeValues.h1 = rangeValues.tempH1;
                rangeValues.h2 = rangeValues.tempH2;
                handle === "handleLeft" ? trueMouseValue = rangeValues.trueYear1 : trueMouseValue = rangeValues.trueYear2;
            }
            
            d3.select(".rangeBarFilled")
                .attr("x", rangeValues.h1)
                .attr("y",0)
                .attr("width", rangeValues.h2 - rangeValues.h1)
                .attr("height",svgDimen.height - margins.bottom)            
        }
        function dragend() {
            rangeValues.h1 = xScale(getTrueMouseValue(rangeValues.tempH1));
            rangeValues.h2 = xScale(getTrueMouseValue(rangeValues.tempH2));
            console.log(rangeValues.trueYear1 + ":" + rangeValues.trueYear2)
            d3.select("." + self.state.handle).attr("transform","translate(" + xScale(trueMouseValue) + ",0)");
            d3.select(".rangeBarFilled")                
                .attr("x", xScale(rangeValues.trueYear1))
                .attr("y", 0)
                .attr("width", xScale(rangeValues.trueYear2) - xScale(rangeValues.trueYear1))
                .attr("height",svgDimen.height - margins.bottom)              

            onChangePeriod(rangeValues.trueYear1, rangeValues.trueYear2);
        }
        function getTrueMouseValue(mouseValue){
            return Math.round(xScale.invert(mouseValue));
        }
    }
}

class GraphSlider extends Component {
    constructor(props){
        super(props);
        this.state = {
            margins: null,
            svgDimen: null,
            total: []
        }
    }
    static getDerivedStateFromProps(nextProps, prevState) {        
        const {total, margins, svgDimen} = nextProps;        
        let newProps = {
            total: total,
            margins: margins,
            svgDimen: svgDimen,
        }
        if(prevState !== newProps)
            return newProps; //set newProps to state
        return null;// no changes
    }    
    componentDidMount(){
        this.renderSliderGraph();
    }
    componentDidUpdate(){
        this.renderSliderGraph();
    }
    renderSliderGraph(){
        const {svgDimen, margins, total} = this.state;        
        let data = total.columns.slice(3).map(function(id){
            return {
                id: id,
                values: total.map(function(d){
                    return{
                        year: d.year,
                        slide: d[id]
                    }
                })
            };
        });
        
        let start = data[0].values[0].year, end = data[0].values[data[0].values.length - 1].year;
        let x = d3.scaleLinear()
            .range([margins.left, svgDimen.width - margins.right])
            .domain([start, end]);
        let y = d3.scaleLinear()
            .range([svgDimen.height - margins.bottom , margins.top])
            .domain([0, 100]);

        let area = d3.area()
            .curve(d3.curveMonotoneX)
            .x(d=> x(d.year))
            .y0(y(0))
            .y1(d => y(d.slide));

        let graph = d3.select(this.GraphAxisElement);
        graph.selectAll("*").remove();

        graph.append("g")
            .attr("transform", "translate(0," + (svgDimen.height - margins.bottom) + ")")
            .call(d3.axisBottom()
                .scale(x)
                .ticks(data[0].values.length)//only slide values length
                .tickFormat(d3.format(""))
            )                        
            .selectAll("text")        
            .style("font-size","10px")
            .style("fill","black");
        graph
            .append("g")
            .call(d3.axisLeft()
                .scale(y)
                .ticks(10)
                .tickSize(0)                
            )
            .select(".domain").style('opacity', 0);
        
        graph.selectAll(".area")
            .data(data)
            .enter().append("path")
                .attr("d", (d) => area(d.values))
                .style("fill", "#ddd");
        graph.selectAll("line").attr("stroke","white");//set black when shows GraphAxis
        graph.select("path").style("d","none");
    }
    render(){
        const {svgDimen, total, margins} = this.state;
        const {onChangePeriod} = this.props;
        let years = total.map(d => d.year);
        console.log('years', years)
        let start = years[0], end = years[years.length - 1];
        let x = d3.scaleLinear()
            .range([margins.left, svgDimen.width - margins.right])
            .domain([start, end]);
        let rangeValues = {h1: x(start), h2: x(end), tempH1: x(start), tempH2: x(end), trueYear1: start, trueYear2: end};
        
        return  <svg className="graphSliderSvg" width={svgDimen.width} height={svgDimen.height}>
                    <g className="graphSliderGroup">                        
                        <g className="graphSliderAxis" ref={el => this.GraphAxisElement = el } />
                        <rect x={x(start)} y="0" width={x(end) - x(start)} height={svgDimen.height - margins.bottom} fill="rgba(54, 174, 175, 0.65)" className="rangeBarFilled" />
                        <Handle className="handleLeft"  onChangePeriod={onChangePeriod} transform={`translate(${x(start)},0)`} svgDimen={svgDimen} margins={margins} handle="handleLeft" years={years} rangeValues={rangeValues} xScale={x} initValue={start}/>
                        <Handle className="handleRight" onChangePeriod={onChangePeriod} transform={`translate(${x(end)},0)`} svgDimen={svgDimen} margins={margins} handle="handleRight" years={years} rangeValues={rangeValues} xScale={x} initValue={end}/>
                    </g>
                </svg>;
    }
    
}

class AreaChart extends Component {
    constructor(props){
        super(props);
        this.state = {
            data: [],
            width: 0,
            height: 0
        };
    }    
    static getDerivedStateFromProps(nextProps, prevState) {     
        const {data, width, height} = nextProps;        
        let newProps = {
            data: data,
            width: width,
            height: height,
            partialData: data
        }
        if(prevState !== newProps)
            return newProps; //set newProps to state
        return null;// no changes
    }    
    componentDidMount(){       
    }
    componentDidUpdate(){        
    }
    changePeriod = (startYear, endYear) => {
        let that = this;
        this.setState({
            partialData: that.getPartial(startYear, endYear)
        });
    }
    getPartial(start, end){
        const {data} = this.state;        
        let partialData = [];
        for(let i = 0; i < data.length; i++){
            if(data[i].year >= start && data[i].year <= end){
                partialData.push(data[i]);
            }
        }
        partialData.push(data.columns);
        return partialData;
    }
    render() {
        const {data, width, height, partialData} = this.state;
        const margins = {top: 20, right: 20, bottom: 20, left: 20},
              svgDimenSlider = {width: width - margins.left - margins.right, height: height/6 },
              svgDimenChart = {width: width - margins.left - margins.right, height: height * 5/6 };
        
        return  <div className="areaChart">
                    <div className="areaChart">
                        <Chart margins={margins} svgDimen={svgDimenChart} partial={partialData}/>
                    </div>
                    <div className="graphSlider">
                        <GraphSlider onChangePeriod={this.changePeriod} margins={margins} svgDimen={svgDimenSlider} total={data}/>
                    </div>                    
                </div>;
    }
}

export default AreaChart;